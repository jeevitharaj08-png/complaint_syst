# Multithreading Demonstration: Concurrent Complaint Ingestion & Resolution

This directory contains a standalone, production-grade multithreading demonstration implemented in **standard C11** using **POSIX Threads (`pthread`)**. It models a high-throughput, concurrent complaint ticket processing pipeline using the classic **Producer-Consumer** architecture with a synchronized **Bounded Buffer**.

---

## 1. Architectural Independence & Isolation

> [!IMPORTANT]
> **Strict Architectural Separation Notice:**
> The production Complaint Handling System (`src/main.c`, `include/complaint_system.h`) remains **strictly single-threaded** and does **not** link with POSIX threads (`-pthread`). This demonstration exists in complete isolation inside `demo_multithreading/` to illustrate enterprise concurrency, synchronization primitives, race-condition elimination, and Helgrind dynamic analysis without altering any production code.

---

## 2. System Architecture & Concurrency Model

The demonstration implements a decoupled, event-driven multi-agent architecture:

```
+-------------------------------------------------------------------------------+
|                             PRODUCER THREADS                                  |
|   [Web Portal Channel]     [Mobile App Channel]     [Email Gateway Channel]   |
+-------------------------------------------------------------------------------+
                                       |
                     queue_push() (Blocks if queue full)
                                       v
+-------------------------------------------------------------------------------+
|               BOUNDED QUEUE (Circular Buffer: Capacity = 8)                  |
|    - Synchronized via pthread_mutex_t queue.mutex                             |
|    - Condition variable: not_full  (wakes blocked producers)                  |
|    - Condition variable: not_empty (wakes waiting agent workers)              |
+-------------------------------------------------------------------------------+
                                       |
                     queue_pop() (Blocks if queue empty)
                                       v
+-------------------------------------------------------------------------------+
|                            WORKER AGENT THREADS                               |
|   [Agent-Alpha (AGT101)]   [Agent-Beta (AGT102)]    [Agent-Gamma (AGT103)]   |
|                          [Agent-Delta (AGT104)]                               |
+-------------------------------------------------------------------------------+
                                       |
                      Triage, Resolution & Safe Metrics Update
                                       v
+-------------------------------------------------------------------------------+
|                      GLOBAL METRICS & CONCURRENCY REPORT                      |
|    - Synchronized via pthread_mutex_t stats.stats_mutex                       |
|    - Zero data races, zero lost updates, zero memory leaks                    |
+-------------------------------------------------------------------------------+
```

### Components

1. **ComplaintTicket**: Encapsulates ticket identifier, customer name, ingestion channel, category, priority, description, timestamp, assigned agent ID, and duration.
2. **ComplaintQueue**: A circular buffer with fixed capacity (`QUEUE_CAPACITY = 8`) to enforce backpressure.
3. **Producer Threads (3 concurrent channels)**:
   - Web Portal Channel
   - Mobile App Channel
   - Email Gateway Channel
4. **Consumer Worker Threads (4 concurrent support agents)**:
   - `Agent-Alpha (AGT101)`
   - `Agent-Beta (AGT102)`
   - `Agent-Gamma (AGT103)`
   - `Agent-Delta (AGT104)`
5. **SystemStats**: Thread-safe aggregator for global metrics (tickets by category, tickets by priority, resolution counts, and workload duration).

---

## 3. POSIX Synchronization Primitives Explained

### A. Mutual Exclusion (`pthread_mutex_t`)

A mutex ensures that only one thread can execute a critical section at any given moment, preventing simultaneous memory accesses that cause data races and corrupted pointers.

- **Queue Mutex (`queue.mutex`)**: Guards internal buffer state, `head`, `tail`, `count`, and the `shutdown` flag.
- **Statistics Mutex (`stats.stats_mutex`)**: Guards shared operational metrics (ticket totals, per-agent counters, resolution timings).
- **Log Mutex (`log_mutex`)**: Guards standard output so concurrent multi-threaded log entries do not interleave or tear across console lines.

#### Lock Hierarchy Protocol (Deadlock Avoidance)
To mathematically prevent **AB-BA deadlocks**, the application enforces a strict two-level lock hierarchy:
1. **Level 1**: `queue.mutex`
2. **Level 2**: `stats.stats_mutex`

**Rule**: No worker thread holding `stats.stats_mutex` ever requests `queue.mutex`. A worker dequeues a ticket under `queue.mutex`, immediately releases `queue.mutex`, simulates work, and then acquires `stats.stats_mutex` independently.

### B. Condition Variables (`pthread_cond_t`)

Condition variables allow threads to sleep efficiently without burning CPU cycles in busy-wait polling loops (`while (1)`).

- **`not_full`**: When the circular buffer reaches maximum capacity (`count == QUEUE_CAPACITY`), incoming producers suspend execution by calling:
  ```c
  pthread_cond_wait(&q->not_full, &q->mutex);
  ```
  When an agent worker dequeues an item, it signals `pthread_cond_signal(&q->not_full)`, waking one suspended producer.
- **`not_empty`**: When the buffer is empty (`count == 0`), idle agent workers suspend execution by calling:
  ```c
  pthread_cond_wait(&q->not_empty, &q->mutex);
  ```
  When a producer enqueues a new complaint, it signals `pthread_cond_signal(&q->not_empty)`, notifying an agent worker to claim the ticket.

#### The Spurious Wakeup Guard Pattern
Per POSIX specification (IEEE Std 1003.1), a thread may wake up from `pthread_cond_wait()` spuriously (without an explicit signal) or another thread may claim the resource first. Therefore, condition waits **must always be wrapped in a `while` loop**, never an `if` statement:

```c
/* Correct POSIX idiom: always re-evaluate predicate */
while (q->count == QUEUE_CAPACITY && !q->shutdown) {
    pthread_cond_wait(&q->not_full, &q->mutex);
}
```

### C. Graceful Shutdown & Queue Draining

Terminating multithreaded systems safely without losing queued tasks or stranding blocked workers requires a coordinated protocol:

1. Producers finish submitting their assigned ticket quota and exit cleanly.
2. The main supervisor thread joins all producer threads (`pthread_join`).
3. The supervisor invokes `queue_shutdown(&queue)`, setting `shutdown = true` and issuing `pthread_cond_broadcast(&q->not_empty)`.
4. The broadcast wakes **all** waiting agent worker threads simultaneously.
5. Workers continue processing remaining tickets in the buffer until `count == 0`, at which point `queue_pop()` returns `false`, causing worker loops to exit cleanly.
6. The main thread joins all worker threads (`pthread_join`).
7. All mutexes and condition variables are destroyed (`pthread_mutex_destroy`, `pthread_cond_destroy`).

---

## 4. Helgrind Dynamic Analysis & Verification

### What is Helgrind?
**Helgrind** is a specialized Valgrind tool designed to detect synchronization errors in C/C++ programs utilizing POSIX pthreads.

Helgrind intercepts all `pthread_*` API invocations and tracks every single memory read and write instruction executed by every thread. It detects three critical classes of bugs:

1. **Misuses of the POSIX pthreads API**:
   - Unlocking a mutex that is unlocked or owned by another thread.
   - Destroying a locked mutex or a condition variable with threads waiting on it.
2. **Potential Deadlocks (Lock Order Inversions)**:
   - Cycle detection in lock acquisition graphs (e.g. Thread 1 acquiring Mutex A then B, while Thread 2 acquires Mutex B then A).
3. **Data Races**:
   - Access to a memory location by two or more threads without a common lock, where at least one thread performs a write operation.

### Running Helgrind

To analyze the demonstration with Helgrind:

```bash
make helgrind
```

This runs:
```bash
valgrind --tool=helgrind --error-exitcode=1 ./demo_multithreading/demo_threads
```

### Interpreting Clean Helgrind Results

A successful, race-free Helgrind execution outputs:

```text
==12345== Helgrind, a data race detector
==12345== Copyright (C) 2007-2024, and GNU GPL'd, by OpenWorks LLP et al.
==12345== Using Valgrind-3.22.0 and LibVEX; rerun with -h for copyright info
...
==12345== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
```

The non-zero exit code (`--error-exitcode=1`) ensures that CI/CD pipelines will immediately fail if any concurrency flaw or race condition is ever introduced.

---

## 5. Build and Execution Targets

The root `Makefile` provides dedicated targets for managing the multithreading demonstration:

| Command | Action |
|---|---|
| `make demo-threads` | Compiles `multithread_demo.c` with `-std=c11 -Wall -Wextra -Wpedantic -pthread`. |
| `make run-threads` | Builds (if needed) and executes the concurrency demonstration. |
| `make helgrind` | Runs the demonstration under Valgrind's Helgrind data-race detector. |

### Manual Build Instructions
If compiling standalone without Make:
```bash
gcc -std=c11 -Wall -Wextra -Wpedantic -pthread demo_multithreading/multithread_demo.c -o demo_multithreading/demo_threads
./demo_multithreading/demo_threads
```

---

## 6. Summary of Concurrency Best Practices Demonstrated

| Concurrency Challenge | Architectural Solution Implemented |
|---|---|
| **Data Races on Buffer** | Protected by `queue.mutex` across all enqueues and dequeues. |
| **Data Races on Counters** | Protected by `stats.stats_mutex` on all increment and timing updates. |
| **Console Output Tearing** | Synchronized with `log_mutex` to preserve readable chronological logging. |
| **Busy-Waiting / High CPU** | Condition variables `not_empty` and `not_full` block threads until state transitions. |
| **Spurious Wakeups** | All condition waits encapsulated within `while (predicate)` loops. |
| **Deadlock (AB-BA)** | Strict lock hierarchy: `queue.mutex` and `stats.stats_mutex` never nested. |
| **Worker Starvation** | Balanced FIFO buffer and fair signaling policy. |
| **Thread Stranding on Exit** | `pthread_cond_broadcast()` awakens all waiting threads during shutdown. |
| **Memory Leaks** | Deterministic teardown with `pthread_join()`, `pthread_mutex_destroy()`, and `pthread_cond_destroy()`. |

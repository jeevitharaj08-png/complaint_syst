#include "test_helpers.h"

extern "C" {

int g_fail_malloc = 0;
int g_fail_malloc_audit_only = 0;
int g_fail_localtime = 0;
int g_fail_fopen = 0;

void* __real_malloc(size_t size);
struct tm* __real_localtime(const time_t* timep);
FILE* __real_fopen(const char* pathname, const char* mode);

void* __wrap_malloc(size_t size) {
    if (g_fail_malloc_audit_only && size == sizeof(AuditNode)) {
        return NULL;
    }
    if (g_fail_malloc) {
        if (size == sizeof(AuditNode) ||
            size == sizeof(CustomerNode) ||
            size == sizeof(ComplaintNode)) {
            return NULL;
        }
    }
    return __real_malloc(size);
}

struct tm* __wrap_localtime(const time_t* timep) {
    if (g_fail_localtime) {
        return NULL;
    }
    return __real_localtime(timep);
}

FILE* __wrap_fopen(const char* pathname, const char* mode) {
    if (g_fail_fopen) {
        return NULL;
    }
    return __real_fopen(pathname, mode);
}

}

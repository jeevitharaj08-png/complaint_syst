#include "test_helpers.h"

class StorageTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {}

    void TearDown() override {
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FUNCTION 8: initSystem Tests                                              */
/* ========================================================================= */

TEST_F(StorageTest, InitSystem_ColdStartAndPaddedDefaults) {
    // 1. Cold start: empty sandbox
    freeAllMemory();
    initSystem();
    saveAllData();

    std::string counters = sandbox.readFile("data/counters.txt");
    EXPECT_NE(counters.find("101"), std::string::npos);
    EXPECT_NE(counters.find("1001"), std::string::npos);

    std::string agents = sandbox.readFile("data/agents.txt");
    EXPECT_NE(agents.find("AGT101|Alice Smith"), std::string::npos);
    EXPECT_NE(agents.find("AGT110|Julia Roberts"), std::string::npos);

    // 2. Partial agents: 2 custom agents padded to MAX_AGENTS (10)
    freeAllMemory();
    sandbox.writeFile("data/agents.txt",
        "AGT101|Custom Alice|user1|pass1|1|5\n"
        "AGT102|Custom Bob|user2|pass2|0|2\n");
    initSystem();
    saveAllData();

    std::string agents2 = sandbox.readFile("data/agents.txt");
    EXPECT_NE(agents2.find("AGT101|Custom Alice|user1|pass1|1|5"), std::string::npos);
    EXPECT_NE(agents2.find("AGT102|Custom Bob|user2|pass2|0|2"), std::string::npos);
    EXPECT_NE(agents2.find("AGT103|Charlie Brown"), std::string::npos);
    EXPECT_NE(agents2.find("AGT110|Julia Roberts"), std::string::npos);
}

TEST_F(StorageTest, InitSystem_CorruptCountersAndNormalEntityLoading) {
    // 1. Corrupt counters clamped
    freeAllMemory();
    sandbox.writeFile("data/counters.txt", "invalid_data\n");
    initSystem();
    saveAllData();
    std::string c1 = sandbox.readFile("data/counters.txt");
    EXPECT_NE(c1.find("101"), std::string::npos);

    freeAllMemory();
    sandbox.writeFile("data/counters.txt", "50\n500\n");
    initSystem();
    saveAllData();
    std::string c2 = sandbox.readFile("data/counters.txt");
    EXPECT_NE(c2.find("101"), std::string::npos);

    // 2. Load customers, complaints, and audit nodes (with 4-field fallback)
    freeAllMemory();
    sandbox.writeFile("data/customers.txt",
        "CUST1001|Alice|alice|p1|c1\n"
        "CUST1005|Bob|bob|p2|c2\n");
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Cat|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|D1\n"
        "CMP109|CUST1005|Cat|Low|PENDING|UNASSIGNED|2026-01-01 11:00:00|N/A|2026-01-01 11:00:00|N/A|N/A|N/A|Note|D2\n");
    sandbox.writeFile("data/audit_log.txt",
        "CMP101|2026-01-01 10:00:00|LOGGED|CUST1001|Details 1\n"
        "CMP101|2026-01-01 10:05:00|LOGGED2|SYSTEM\n"
        "CMP101|2026-01-01 10:10:00|LOGGED3|SYSTEM|Details 3\n"
        "CMP999|2026-01-01 10:00:00|LOGGED|UNKNOWN|Non-existent complaint\n");

    initSystem();

    EXPECT_NE(findCustomerByUsername("alice"), nullptr);
    EXPECT_NE(findCustomerByUsername("bob"), nullptr);

    ComplaintNode *cmp101 = findComplaintById("CMP101");
    ASSERT_NE(cmp101, nullptr);
    ASSERT_NE(cmp101->auditHead, nullptr);
    EXPECT_STREQ(cmp101->auditHead->action, "LOGGED");
    ASSERT_NE(cmp101->auditHead->next, nullptr);
    EXPECT_STREQ(cmp101->auditHead->next->action, "LOGGED2");
    EXPECT_STREQ(cmp101->auditHead->next->details, ""); // 4-field branch
    ASSERT_NE(cmp101->auditHead->next->next, nullptr);
    EXPECT_STREQ(cmp101->auditHead->next->next->action, "LOGGED3");
}

TEST_F(StorageTest, InitSystem_MalformedDataAndDefensiveFailures) {
    // 1. Malformed lines across all 4 files
    freeAllMemory();
    sandbox.writeFile("data/agents.txt",
        "MALFORMED_LINE\n"
        "AGT101|Alice Smith|agent1|pass1|1|0\n");
    sandbox.writeFile("data/customers.txt",
        "MALFORMED_LINE\n"
        "USER999|NonStandard|nonstd|pass|contact\n"
        "CUST900|LowerNumber|lower|pass|contact\n"
        "CUST1001|NormalUser|normal|pass|contact\n");
    sandbox.writeFile("data/complaints.txt",
        "MALFORMED_LINE\n"
        "TICKET100|CUST1001|Cat|High|PENDING|UNASSIGNED|2026-01-01|2026-01-01|2026-01-01|N/A|N/A|N/A|Note|Desc\n"
        "CMP50|CUST1001|Cat|High|PENDING|UNASSIGNED|2026-01-01|2026-01-01|2026-01-01|N/A|N/A|N/A|Note|Desc\n"
        "CMP101|CUST1001|Cat|High|PENDING|UNASSIGNED|2026-01-01|2026-01-01|2026-01-01|N/A|N/A|N/A|Note|Desc\n");
    sandbox.writeFile("data/audit_log.txt",
        "MALFORMED\n"
        "CMP101|2026-01-01 10:00:00|ACTION|ACTOR|Details\n");

    initSystem();
    EXPECT_NE(findCustomerByUsername("normal"), nullptr);
    EXPECT_NE(findComplaintById("CMP101"), nullptr);

    // 2. System memory allocation failures
    {
        freeAllMemory();
        FailMallocGuard guard;
        initSystem();
    }

    // 3. Audit node specific malloc failure
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Cat|High|PENDING|UNASSIGNED|2026-01-01|2026-01-01|2026-01-01|N/A|N/A|N/A|Note|Desc\n");
        sandbox.writeFile("data/audit_log.txt", "CMP101|2026-01-01 10:00:00|ACT|BY|Detail\n");

        g_fail_malloc_audit_only = 1;
        initSystem();
        g_fail_malloc_audit_only = 0;
        ComplaintNode *node = findComplaintById("CMP101");
        ASSERT_NE(node, nullptr);
        EXPECT_EQ(node->auditHead, nullptr);
    }
}

/* ========================================================================= */
/* FUNCTION 9: saveAllData Tests                                             */
/* ========================================================================= */

TEST_F(StorageTest, SaveAllData_NormalAndFopenFailures) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Cat|High|PENDING|UNASSIGNED|2026-01-01|2026-01-01|2026-01-01|N/A|N/A|N/A|Existing note|Description\n");
    initSystem();

    // 1. Normal save with empty fields triggering fallback strings
    ComplaintNode *node = findComplaintById("CMP101");
    ASSERT_NE(node, nullptr);
    node->data.timestamps.registered[0] = '\0';
    node->data.timestamps.assigned[0] = '\0';
    node->data.timestamps.updated[0] = '\0';
    node->data.timestamps.resolved[0] = '\0';
    node->data.timestamps.closed[0] = '\0';
    node->data.timestamps.escalated[0] = '\0';
    node->data.lastNote[0] = '\0';

    saveAllData();
    std::string compContent = sandbox.readFile("data/complaints.txt");
    EXPECT_NE(compContent.find("N/A|N/A|N/A|N/A|N/A|N/A|No notes yet"), std::string::npos);

    // 2. Fopen failures handled safely
    {
        FailFopenGuard guard;
        saveAllData();
    }
}

/* ========================================================================= */
/* FUNCTION 10: freeAllMemory Tests                                          */
/* ========================================================================= */

TEST_F(StorageTest, FreeAllMemory_EmptyAndPopulated) {
    // 1. Safe on empty lists
    freeAllMemory();
    freeAllMemory();

    // 2. Clean deallocation on populated list
    sandbox.writeFile("data/customers.txt", "CUST1001|Alice|alice|p1|c1\n");
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Cat|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|D1\n");
    sandbox.writeFile("data/audit_log.txt", "CMP101|2026-01-01 10:00:00|ACTION|ACTOR|Detail\n");
    initSystem();

    freeAllMemory();
    EXPECT_EQ(findCustomerByUsername("alice"), nullptr);
    EXPECT_EQ(findComplaintById("CMP101"), nullptr);
}

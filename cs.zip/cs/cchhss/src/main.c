#include "../include/complaint_system.h"

/* Global in-memory storage */
static CustomerNode *customerHead = NULL;
static ComplaintNode *complaintHead = NULL;
static Agent agents[MAX_AGENTS];
static Manager managerAccount = {"manager", "manager123", "Operations Manager"};

static int nextComplaintNum = 101;
static int nextCustomerNum = 1001;

/* Lookup tables for Categories and Priorities */
static const char *CATEGORIES[] = {
    "Technical Support",
    "Billing and Account",
    "Customer Service",
    "Logistics Support",
    "Other"
};
static const int CATEGORY_COUNT = 5;

static const char *PRIORITIES[] = {
    "Low",
    "Medium",
    "High",
    "Critical"
};
static const int PRIORITY_COUNT = 4;

/* ========================================================================= */
/* FUNCTION 1: getTimestamp                                                  */
/* Populates buffer with formatted current timestamp (YYYY-MM-DD HH:MM:SS)   */
/* ========================================================================= */
void getTimestamp(char *buffer, size_t size) {
    if (buffer == NULL || size == 0) return;
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    if (tm_info != NULL) {
        strftime(buffer, size, "%Y-%m-%d %H:%M:%S", tm_info);
    } else {
        snprintf(buffer, size, "N/A");
    }
}

/* ========================================================================= */
/* FUNCTION 2: readString                                                    */
/* Safely reads a line from stdin, removes newline, and sanitizes input      */
/* ========================================================================= */
void readString(const char *prompt, char *buffer, size_t size) {
    if (prompt != NULL && prompt[0] != '\0') {
        printf("%s", prompt);
        fflush(stdout);
    }
    if (buffer == NULL || size == 0) return;

    if (fgets(buffer, (int)size, stdin) == NULL) {
        buffer[0] = '\0';
        return;
    }

    size_t len = strlen(buffer);
    while (len > 0 && (buffer[len - 1] == '\n' || buffer[len - 1] == '\r')) {
        buffer[len - 1] = '\0';
        len--;
    }

    /* Replace pipe characters to protect persistent storage delimiter integrity */
    for (size_t i = 0; i < len; i++) {
        if (buffer[i] == '|') {
            buffer[i] = '-';
        }
    }
}

/* ========================================================================= */
/* FUNCTION 3: readInt                                                       */
/* Robust integer input with validation and buffer flushing to avoid loops  */
/* ========================================================================= */
int readInt(const char *prompt, int minVal, int maxVal) {
    char buffer[64];
    while (1) {
        readString(prompt, buffer, sizeof(buffer));
        if (buffer[0] == '\0') {
            if (feof(stdin)) {
                return minVal;
            }
            printf("Input cannot be empty. Please enter a number between %d and %d: ", minVal, maxVal);
            continue;
        }

        char *endptr = NULL;
        long parsed = strtol(buffer, &endptr, 10);
        if (endptr != buffer && *endptr == '\0') {
            if (parsed >= minVal && parsed <= maxVal) {
                return (int)parsed;
            }
        }
        printf("Invalid choice. Please enter a number between %d and %d: ", minVal, maxVal);
    }
}

/* ========================================================================= */
/* FUNCTION 4: findCustomerByUsername                                        */
/* Traverses customer linked list to locate an account by username           */
/* ========================================================================= */
CustomerNode* findCustomerByUsername(const char *username) {
    if (username == NULL || username[0] == '\0') return NULL;
    CustomerNode *curr = customerHead;
    while (curr != NULL) {
        if (strcmp(curr->data.username, username) == 0) {
            return curr;
        }
        curr = curr->next;
    }
    return NULL;
}

/* ========================================================================= */
/* FUNCTION 5: findComplaintById                                             */
/* Traverses complaint linked list to locate a record by its complaint ID    */
/* ========================================================================= */
ComplaintNode* findComplaintById(const char *complaintId) {
    if (complaintId == NULL || complaintId[0] == '\0') return NULL;
    ComplaintNode *curr = complaintHead;
    while (curr != NULL) {
        if (strcmp(curr->data.complaintId, complaintId) == 0) {
            return curr;
        }
        curr = curr->next;
    }
    return NULL;
}

/* ========================================================================= */
/* FUNCTION 6: addAuditEntry                                                 */
/* Allocates and appends a chronological audit record to a complaint        */
/* ========================================================================= */
void addAuditEntry(ComplaintNode *node, const char *action, const char *by, const char *details) {
    if (node == NULL) return;
    AuditNode *newAudit = (AuditNode *)malloc(sizeof(AuditNode));
    if (newAudit == NULL) {
        printf("Error: Memory allocation failed for audit entry.\n");
        return;
    }

    snprintf(newAudit->complaintId, sizeof(newAudit->complaintId), "%s", node->data.complaintId);
    getTimestamp(newAudit->timestamp, sizeof(newAudit->timestamp));
    snprintf(newAudit->action, sizeof(newAudit->action), "%s", action ? action : "ACTION");
    snprintf(newAudit->performedBy, sizeof(newAudit->performedBy), "%s", by ? by : "SYSTEM");
    snprintf(newAudit->details, sizeof(newAudit->details), "%s", details ? details : "");
    newAudit->next = NULL;

    if (node->auditHead == NULL) {
        node->auditHead = newAudit;
    } else {
        AuditNode *curr = node->auditHead;
        while (curr->next != NULL) {
            curr = curr->next;
        }
        curr->next = newAudit;
    }
}

/* ========================================================================= */
/* FUNCTION 7: autoAssignAgent                                               */
/* Identifies active agent with least open workload for optimal assignment   */
/* ========================================================================= */
int autoAssignAgent(void) {
    int candidateIndex = -1;
    int minWorkload = 999999;

    for (int i = 0; i < MAX_AGENTS; i++) {
        if (!agents[i].isActive) continue;

        int activeWorkload = 0;
        ComplaintNode *curr = complaintHead;
        while (curr != NULL) {
            if (strcmp(curr->data.assignedAgentId, agents[i].agentId) == 0) {
                if (strcmp(curr->data.status, "RESOLVED") != 0 &&
                    strcmp(curr->data.status, "CLOSED") != 0) {
                    activeWorkload++;
                }
            }
            curr = curr->next;
        }

        if (activeWorkload < minWorkload) {
            minWorkload = activeWorkload;
            candidateIndex = i;
        }
    }
    return candidateIndex;
}

/* ========================================================================= */
/* FUNCTION 8: initSystem                                                    */
/* Loads or initializes configurations, agent accounts, and persisted data  */
/* Ensures zero complaints and starts complaint numbering strictly at CMP101 */
/* ========================================================================= */
void initSystem(void) {
    CREATE_DIR("data");

    /* Initialize 10 predefined support agents */
    const char *names[MAX_AGENTS] = {
        "Alice Smith", "Bob Johnson", "Charlie Brown", "Diana Prince",
        "Edward Stark", "Fiona Gallagher", "George Clark", "Hannah Abbott",
        "Ian Malcolm", "Julia Roberts"
    };

    FILE *fAgent = fopen("data/agents.txt", "r");
    if (fAgent == NULL) {
        for (int i = 0; i < MAX_AGENTS; i++) {
            snprintf(agents[i].agentId, sizeof(agents[i].agentId), "AGT%03d", 101 + i);
            snprintf(agents[i].fullName, sizeof(agents[i].fullName), "%s", names[i]);
            snprintf(agents[i].username, sizeof(agents[i].username), "agent%d", i + 1);
            snprintf(agents[i].password, sizeof(agents[i].password), "agentpass%d", i + 1);
            agents[i].isActive = 1;
            agents[i].resolvedCount = 0;
        }
    } else {
        char line[BUFFER_SIZE];
        int count = 0;
        while (count < MAX_AGENTS && fgets(line, sizeof(line), fAgent) != NULL) {
            char id[16], name[64], user[32], pass[32];
            int active = 1, resolved = 0;
            if (sscanf(line, "%15[^|]|%63[^|]|%31[^|]|%31[^|]|%d|%d",
                       id, name, user, pass, &active, &resolved) >= 4) {
                snprintf(agents[count].agentId, sizeof(agents[count].agentId), "%s", id);
                snprintf(agents[count].fullName, sizeof(agents[count].fullName), "%s", name);
                snprintf(agents[count].username, sizeof(agents[count].username), "%s", user);
                snprintf(agents[count].password, sizeof(agents[count].password), "%s", pass);
                agents[count].isActive = active;
                agents[count].resolvedCount = resolved;
                count++;
            }
        }
        fclose(fAgent);
        for (int i = count; i < MAX_AGENTS; i++) {
            snprintf(agents[i].agentId, sizeof(agents[i].agentId), "AGT%03d", 101 + i);
            snprintf(agents[i].fullName, sizeof(agents[i].fullName), "%s", names[i]);
            snprintf(agents[i].username, sizeof(agents[i].username), "agent%d", i + 1);
            snprintf(agents[i].password, sizeof(agents[i].password), "agentpass%d", i + 1);
            agents[i].isActive = 1;
            agents[i].resolvedCount = 0;
        }
    }

    /* Load Persistent Counters */
    FILE *fCounters = fopen("data/counters.txt", "r");
    if (fCounters != NULL) {
        if (fscanf(fCounters, "%d\n%d", &nextComplaintNum, &nextCustomerNum) != 2) {
            nextComplaintNum = 101;
            nextCustomerNum = 1001;
        }
        fclose(fCounters);
    } else {
        nextComplaintNum = 101;
        nextCustomerNum = 1001;
    }

    if (nextComplaintNum < 101) nextComplaintNum = 101;
    if (nextCustomerNum < 1001) nextCustomerNum = 1001;

    /* Load Customer Accounts */
    FILE *fCust = fopen("data/customers.txt", "r");
    if (fCust != NULL) {
        char line[BUFFER_SIZE];
        CustomerNode *lastCust = NULL;
        while (fgets(line, sizeof(line), fCust) != NULL) {
            Customer c;
            memset(&c, 0, sizeof(c));
            if (sscanf(line, "%15[^|]|%63[^|]|%31[^|]|%31[^|]|%63[^\r\n]",
                       c.customerId, c.fullName, c.username, c.password, c.contact) == 5) {
                CustomerNode *newNode = (CustomerNode *)malloc(sizeof(CustomerNode));
                if (newNode != NULL) {
                    newNode->data = c;
                    newNode->next = NULL;
                    if (customerHead == NULL) {
                        customerHead = newNode;
                    } else {
                        lastCust->next = newNode;
                    }
                    lastCust = newNode;

                    int cNum = 0;
                    if (sscanf(c.customerId, "CUST%d", &cNum) == 1) {
                        if (cNum >= nextCustomerNum) {
                            nextCustomerNum = cNum + 1;
                        }
                    }
                }
            }
        }
        fclose(fCust);
    }

    /* Load Complaints */
    FILE *fComp = fopen("data/complaints.txt", "r");
    if (fComp != NULL) {
        char line[BUFFER_SIZE];
        ComplaintNode *lastComp = NULL;
        while (fgets(line, sizeof(line), fComp) != NULL) {
            Complaint comp;
            memset(&comp, 0, sizeof(comp));
            int parsed = sscanf(line,
                "%15[^|]|%15[^|]|%31[^|]|%15[^|]|%19[^|]|%15[^|]|%25[^|]|%25[^|]|%25[^|]|%25[^|]|%25[^|]|%25[^|]|%127[^|]|%255[^\r\n]",
                comp.complaintId, comp.customerId, comp.category, comp.priority, comp.status,
                comp.assignedAgentId, comp.timestamps.registered, comp.timestamps.assigned,
                comp.timestamps.updated, comp.timestamps.resolved, comp.timestamps.closed,
                comp.timestamps.escalated, comp.lastNote, comp.description);

            if (parsed == 14) {
                ComplaintNode *newCNode = (ComplaintNode *)malloc(sizeof(ComplaintNode));
                if (newCNode != NULL) {
                    newCNode->data = comp;
                    newCNode->auditHead = NULL;
                    newCNode->next = NULL;
                    if (complaintHead == NULL) {
                        complaintHead = newCNode;
                    } else {
                        lastComp->next = newCNode;
                    }
                    lastComp = newCNode;

                    int cmpNum = 0;
                    if (sscanf(comp.complaintId, "CMP%d", &cmpNum) == 1) {
                        if (cmpNum >= nextComplaintNum) {
                            nextComplaintNum = cmpNum + 1;
                        }
                    }
                }
            }
        }
        fclose(fComp);
    }

    /* Load Audit Logs */
    FILE *fAudit = fopen("data/audit_log.txt", "r");
    if (fAudit != NULL) {
        char line[BUFFER_SIZE];
        while (fgets(line, sizeof(line), fAudit) != NULL) {
            char compId[16], tstamp[26], action[32], by[32], details[128];
            int p = sscanf(line, "%15[^|]|%25[^|]|%31[^|]|%31[^|]|%127[^\r\n]",
                           compId, tstamp, action, by, details);
            if (p >= 4) {
                if (p == 4) details[0] = '\0';
                ComplaintNode *target = findComplaintById(compId);
                if (target != NULL) {
                    AuditNode *an = (AuditNode *)malloc(sizeof(AuditNode));
                    if (an != NULL) {
                        snprintf(an->complaintId, sizeof(an->complaintId), "%s", compId);
                        snprintf(an->timestamp, sizeof(an->timestamp), "%s", tstamp);
                        snprintf(an->action, sizeof(an->action), "%s", action);
                        snprintf(an->performedBy, sizeof(an->performedBy), "%s", by);
                        snprintf(an->details, sizeof(an->details), "%s", details);
                        an->next = NULL;

                        if (target->auditHead == NULL) {
                            target->auditHead = an;
                        } else {
                            AuditNode *curA = target->auditHead;
                            while (curA->next != NULL) {
                                curA = curA->next;
                            }
                            curA->next = an;
                        }
                    }
                }
            }
        }
        fclose(fAudit);
    }
}

/* ========================================================================= */
/* FUNCTION 9: saveAllData                                                   */
/* Persists counters, customers, complaints, audit logs, and agents to disk  */
/* ========================================================================= */
void saveAllData(void) {
    CREATE_DIR("data");

    /* Save Counters */
    FILE *fCounters = fopen("data/counters.txt", "w");
    if (fCounters != NULL) {
        fprintf(fCounters, "%d\n%d\n", nextComplaintNum, nextCustomerNum);
        fclose(fCounters);
    }

    /* Save Agents */
    FILE *fAgent = fopen("data/agents.txt", "w");
    if (fAgent != NULL) {
        for (int i = 0; i < MAX_AGENTS; i++) {
            fprintf(fAgent, "%s|%s|%s|%s|%d|%d\n",
                    agents[i].agentId, agents[i].fullName, agents[i].username,
                    agents[i].password, agents[i].isActive, agents[i].resolvedCount);
        }
        fclose(fAgent);
    }

    /* Save Customers */
    FILE *fCust = fopen("data/customers.txt", "w");
    if (fCust != NULL) {
        CustomerNode *curr = customerHead;
        while (curr != NULL) {
            fprintf(fCust, "%s|%s|%s|%s|%s\n",
                    curr->data.customerId, curr->data.fullName,
                    curr->data.username, curr->data.password, curr->data.contact);
            curr = curr->next;
        }
        fclose(fCust);
    }

    /* Save Complaints */
    FILE *fComp = fopen("data/complaints.txt", "w");
    if (fComp != NULL) {
        ComplaintNode *curr = complaintHead;
        while (curr != NULL) {
            fprintf(fComp, "%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s\n",
                    curr->data.complaintId, curr->data.customerId, curr->data.category,
                    curr->data.priority, curr->data.status, curr->data.assignedAgentId,
                    curr->data.timestamps.registered[0] ? curr->data.timestamps.registered : "N/A",
                    curr->data.timestamps.assigned[0] ? curr->data.timestamps.assigned : "N/A",
                    curr->data.timestamps.updated[0] ? curr->data.timestamps.updated : "N/A",
                    curr->data.timestamps.resolved[0] ? curr->data.timestamps.resolved : "N/A",
                    curr->data.timestamps.closed[0] ? curr->data.timestamps.closed : "N/A",
                    curr->data.timestamps.escalated[0] ? curr->data.timestamps.escalated : "N/A",
                    curr->data.lastNote[0] ? curr->data.lastNote : "No notes yet",
                    curr->data.description);
            curr = curr->next;
        }
        fclose(fComp);
    }

    /* Save Audit Logs */
    FILE *fAudit = fopen("data/audit_log.txt", "w");
    if (fAudit != NULL) {
        ComplaintNode *cNode = complaintHead;
        while (cNode != NULL) {
            AuditNode *aNode = cNode->auditHead;
            while (aNode != NULL) {
                fprintf(fAudit, "%s|%s|%s|%s|%s\n",
                        aNode->complaintId, aNode->timestamp, aNode->action,
                        aNode->performedBy, aNode->details);
                aNode = aNode->next;
            }
            cNode = cNode->next;
        }
        fclose(fAudit);
    }
}

/* ========================================================================= */
/* FUNCTION 10: freeAllMemory                                                */
/* Traverses and releases all dynamically allocated memory for all nodes     */
/* ========================================================================= */
void freeAllMemory(void) {
    CustomerNode *cCurr = customerHead;
    while (cCurr != NULL) {
        CustomerNode *temp = cCurr;
        cCurr = cCurr->next;
        free(temp);
    }
    customerHead = NULL;

    ComplaintNode *cmpCurr = complaintHead;
    while (cmpCurr != NULL) {
        ComplaintNode *tempC = cmpCurr;
        AuditNode *aCurr = cmpCurr->auditHead;
        while (aCurr != NULL) {
            AuditNode *tempA = aCurr;
            aCurr = aCurr->next;
            free(tempA);
        }
        cmpCurr = cmpCurr->next;
        free(tempC);
    }
    complaintHead = NULL;
}

/* ========================================================================= */
/* FUNCTION 11: customerMenu                                                 */
/* Submenu before login for customer registration and authentication         */
/* ========================================================================= */
void customerMenu(void) {
    while (1) {
        printf("\n----------------------------------------\n");
        printf("            CUSTOMER PORTAL\n");
        printf("----------------------------------------\n");
        printf("1. Register a new account\n");
        printf("2. Login\n");
        printf("3. Return to main menu\n\n");

        int choice = readInt("Enter your choice: ", 1, 3);
        if (choice == 1) {
            customerRegister();
        } else if (choice == 2) {
            customerLogin();
        } else {
            break;
        }
    }
}

/* ========================================================================= */
/* FUNCTION 12: customerRegister                                             */
/* Registers a new customer account persistently without creating complaints */
/* ========================================================================= */
void customerRegister(void) {
    char fullName[64], username[32], password[32], contact[64];

    printf("\n=== Customer Account Registration ===\n");
    readString("Enter Full Name: ", fullName, sizeof(fullName));
    if (fullName[0] == '\0') {
        printf("Registration cancelled: Full name cannot be blank.\n");
        return;
    }

    readString("Enter Desired Username: ", username, sizeof(username));
    if (username[0] == '\0') {
        printf("Registration cancelled: Username cannot be blank.\n");
        return;
    }

    if (findCustomerByUsername(username) != NULL) {
        printf("Error: Username '%s' is already taken. Please choose a different username.\n", username);
        return;
    }

    readString("Enter Password: ", password, sizeof(password));
    if (password[0] == '\0') {
        printf("Registration cancelled: Password cannot be blank.\n");
        return;
    }

    readString("Enter Email Address or Phone: ", contact, sizeof(contact));
    if (contact[0] == '\0') {
        printf("Registration cancelled: Contact details cannot be blank.\n");
        return;
    }

    CustomerNode *newNode = (CustomerNode *)malloc(sizeof(CustomerNode));
    if (newNode == NULL) {
        printf("Error: System memory allocation failed.\n");
        return;
    }

    snprintf(newNode->data.customerId, sizeof(newNode->data.customerId), "CUST%04d", nextCustomerNum++);
    snprintf(newNode->data.fullName, sizeof(newNode->data.fullName), "%s", fullName);
    snprintf(newNode->data.username, sizeof(newNode->data.username), "%s", username);
    snprintf(newNode->data.password, sizeof(newNode->data.password), "%s", password);
    snprintf(newNode->data.contact, sizeof(newNode->data.contact), "%s", contact);
    newNode->next = NULL;

    if (customerHead == NULL) {
        customerHead = newNode;
    } else {
        CustomerNode *curr = customerHead;
        while (curr->next != NULL) {
            curr = curr->next;
        }
        curr->next = newNode;
    }

    saveAllData();
    printf("\n[SUCCESS] Account created successfully! Your Customer ID is: %s\n", newNode->data.customerId);
    printf("Please log in with your credentials to access services.\n");
}

/* ========================================================================= */
/* FUNCTION 13: customerLogin                                                */
/* Authenticates customer credentials and displays dashboard                 */
/* ========================================================================= */
void customerLogin(void) {
    char username[32], password[32];

    printf("\n=== Customer Login ===\n");
    readString("Username: ", username, sizeof(username));
    readString("Password: ", password, sizeof(password));

    CustomerNode *user = findCustomerByUsername(username);
    if (user != NULL && strcmp(user->data.password, password) == 0) {
        printf("\nWelcome back, %s!\n", user->data.fullName);
        customerDashboard(user->data.customerId, user->data.fullName);
    } else {
        printf("\nAuthentication failed: Invalid username or password.\n");
    }
}

/* ========================================================================= */
/* FUNCTION 14: customerDashboard                                            */
/* Customer dashboard after successful authentication                        */
/* ========================================================================= */
void customerDashboard(const char *customerId, const char *customerName) {
    while (1) {
        printf("\n----------------------------------------\n");
        printf("   CUSTOMER DASHBOARD: %s (%s)\n", customerName, customerId);
        printf("----------------------------------------\n");
        printf("1. Register a complaint\n");
        printf("2. View my complaints\n");
        printf("3. Track complaint by ID\n");
        printf("4. View complaint history\n");
        printf("5. Logout\n\n");

        int choice = readInt("Enter your choice: ", 1, 5);
        if (choice == 1) {
            customerRegisterComplaint(customerId);
        } else if (choice == 2) {
            customerViewComplaints(customerId);
        } else if (choice == 3) {
            customerTrackComplaint(customerId);
        } else if (choice == 4) {
            customerViewHistory(customerId);
        } else {
            printf("Logging out of customer session...\n");
            break;
        }
    }
}

/* ========================================================================= */
/* FUNCTION 15: customerRegisterComplaint                                    */
/* Registers a genuine customer complaint with guaranteed CMP101+ ID         */
/* ========================================================================= */
void customerRegisterComplaint(const char *customerId) {
    printf("\n=== Register a New Complaint ===\n");

    printf("\nSelect Complaint Category:\n");
    for (int i = 0; i < CATEGORY_COUNT; i++) {
        printf("  %d. %s\n", i + 1, CATEGORIES[i]);
    }
    int catChoice = readInt("Select category (1-5): ", 1, CATEGORY_COUNT);
    const char *selectedCategory = CATEGORIES[catChoice - 1];

    printf("\nSelect Complaint Priority:\n");
    for (int i = 0; i < PRIORITY_COUNT; i++) {
        printf("  %d. %s\n", i + 1, PRIORITIES[i]);
    }
    int priChoice = readInt("Select priority (1-4): ", 1, PRIORITY_COUNT);
    const char *selectedPriority = PRIORITIES[priChoice - 1];

    char description[256];
    readString("Enter detailed complaint description: ", description, sizeof(description));
    if (description[0] == '\0') {
        printf("Registration aborted: Description cannot be empty.\n");
        return;
    }

    /* Persistent ID sequence starting strictly at CMP101 */
    char newId[16];
    while (1) {
        snprintf(newId, sizeof(newId), "CMP%d", nextComplaintNum);
        if (findComplaintById(newId) == NULL) {
            break;
        }
        nextComplaintNum++;
    }

    ComplaintNode *newNode = (ComplaintNode *)malloc(sizeof(ComplaintNode));
    if (newNode == NULL) {
        printf("Error: Memory allocation failed. Complaint not registered.\n");
        return;
    }

    memset(&newNode->data, 0, sizeof(Complaint));
    snprintf(newNode->data.complaintId, sizeof(newNode->data.complaintId), "%s", newId);
    snprintf(newNode->data.customerId, sizeof(newNode->data.customerId), "%s", customerId);
    snprintf(newNode->data.category, sizeof(newNode->data.category), "%s", selectedCategory);
    snprintf(newNode->data.priority, sizeof(newNode->data.priority), "%s", selectedPriority);
    snprintf(newNode->data.description, sizeof(newNode->data.description), "%s", description);
    snprintf(newNode->data.lastNote, sizeof(newNode->data.lastNote), "Complaint lodged by customer.");
    newNode->auditHead = NULL;
    newNode->next = NULL;

    getTimestamp(newNode->data.timestamps.registered, sizeof(newNode->data.timestamps.registered));
    snprintf(newNode->data.timestamps.updated, sizeof(newNode->data.timestamps.updated), "%s", newNode->data.timestamps.registered);
    snprintf(newNode->data.timestamps.resolved, sizeof(newNode->data.timestamps.resolved), "N/A");
    snprintf(newNode->data.timestamps.closed, sizeof(newNode->data.timestamps.closed), "N/A");
    snprintf(newNode->data.timestamps.escalated, sizeof(newNode->data.timestamps.escalated), "N/A");

    /* Auto-assign to least loaded active agent */
    int agentIdx = autoAssignAgent();
    if (agentIdx >= 0) {
        snprintf(newNode->data.assignedAgentId, sizeof(newNode->data.assignedAgentId), "%s", agents[agentIdx].agentId);
        snprintf(newNode->data.status, sizeof(newNode->data.status), "ASSIGNED");
        snprintf(newNode->data.timestamps.assigned, sizeof(newNode->data.timestamps.assigned), "%s", newNode->data.timestamps.registered);
    } else {
        snprintf(newNode->data.assignedAgentId, sizeof(newNode->data.assignedAgentId), "UNASSIGNED");
        snprintf(newNode->data.status, sizeof(newNode->data.status), "PENDING");
        snprintf(newNode->data.timestamps.assigned, sizeof(newNode->data.timestamps.assigned), "N/A");
    }

    /* Append to singly linked list of complaints */
    if (complaintHead == NULL) {
        complaintHead = newNode;
    } else {
        ComplaintNode *curr = complaintHead;
        while (curr->next != NULL) {
            curr = curr->next;
        }
        curr->next = newNode;
    }

    /* Record audit trail */
    addAuditEntry(newNode, "REGISTERED", customerId, "Complaint registered by customer");
    if (agentIdx >= 0) {
        char assignNote[128];
        snprintf(assignNote, sizeof(assignNote), "Auto-assigned to %s (%s)", agents[agentIdx].agentId, agents[agentIdx].fullName);
        addAuditEntry(newNode, "ASSIGNED", "SYSTEM", assignNote);
    }

    nextComplaintNum++;
    saveAllData();

    printf("\n============================================================\n");
    printf(" [SUCCESS] Complaint Registered Successfully!\n");
    printf(" Complaint ID:       %s\n", newNode->data.complaintId);
    printf(" Status:             %s\n", newNode->data.status);
    if (agentIdx >= 0) {
        printf(" Assigned Agent:     %s (%s)\n", agents[agentIdx].agentId, agents[agentIdx].fullName);
    } else {
        printf(" Assigned Agent:     Pending Manager Assignment\n");
    }
    printf(" Registered At:      %s\n", newNode->data.timestamps.registered);
    printf("============================================================\n");
}

/* ========================================================================= */
/* FUNCTION 16: customerViewComplaints                                       */
/* Displays tabular summary of all complaints filed by the customer          */
/* ========================================================================= */
void customerViewComplaints(const char *customerId) {
    printf("\n=== My Registered Complaints ===\n");
    printf("%-8s | %-20s | %-8s | %-12s | %-10s | %-19s\n",
           "ID", "Category", "Priority", "Status", "Agent", "Registered Date");
    printf("----------------------------------------------------------------------------------------\n");

    int count = 0;
    ComplaintNode *curr = complaintHead;
    while (curr != NULL) {
        if (strcmp(curr->data.customerId, customerId) == 0) {
            printf("%-8s | %-20s | %-8s | %-12s | %-10s | %-19s\n",
                   curr->data.complaintId,
                   curr->data.category,
                   curr->data.priority,
                   curr->data.status,
                   curr->data.assignedAgentId,
                   curr->data.timestamps.registered);
            count++;
        }
        curr = curr->next;
    }

    if (count == 0) {
        printf("No complaints found under your account.\n");
    } else {
        printf("----------------------------------------------------------------------------------------\n");
        printf("Total Complaints: %d\n", count);
    }
}

/* ========================================================================= */
/* FUNCTION 17: customerTrackComplaint                                       */
/* Provides complete progress summary, status card, and timeline for an ID  */
/* ========================================================================= */
void customerTrackComplaint(const char *customerId) {
    char compId[16];
    readString("Enter Complaint ID to track (e.g. CMP101): ", compId, sizeof(compId));

    ComplaintNode *node = findComplaintById(compId);
    if (node == NULL) {
        printf("Error: Complaint ID '%s' not found.\n", compId);
        return;
    }

    if (strcmp(node->data.customerId, customerId) != 0) {
        printf("Security violation: You are not authorized to view complaints belonging to another customer.\n");
        return;
    }

    printf("\n============================================================\n");
    printf("               COMPLAINT TRACKING: %s\n", node->data.complaintId);
    printf("============================================================\n");
    printf(" Customer ID:        %s\n", node->data.customerId);
    printf(" Category:           %s\n", node->data.category);
    printf(" Priority:           %s\n", node->data.priority);
    printf(" Current Status:     %s\n", node->data.status);
    printf(" Assigned Agent:     %s\n", node->data.assignedAgentId);
    printf(" Description:        %s\n", node->data.description);
    printf(" Latest Note:        %s\n", node->data.lastNote);
    printf("------------------------------------------------------------\n");
    printf(" PROGRESS TIMELINE:\n");
    printf("   Registration:     %s\n", node->data.timestamps.registered);
    printf("   Assignment:       %s\n", node->data.timestamps.assigned);
    printf("   Last Updated:     %s\n", node->data.timestamps.updated);
    printf("   Resolution:       %s\n", node->data.timestamps.resolved);
    printf("   Closure:          %s\n", node->data.timestamps.closed);
    printf("   Escalation:       %s\n", node->data.timestamps.escalated);
    printf("------------------------------------------------------------\n");

    printf(" STAGE PROGRESSION:  ");
    if (strcmp(node->data.status, "PENDING") == 0) {
        printf("[Stage 1/5] Received & Queued for Agent\n");
    } else if (strcmp(node->data.status, "ASSIGNED") == 0) {
        printf("[Stage 2/5] Assigned to Support Agent\n");
    } else if (strcmp(node->data.status, "IN_PROGRESS") == 0) {
        printf("[Stage 3/5] Active Investigation & Troubleshooting\n");
    } else if (strcmp(node->data.status, "ESCALATED") == 0) {
        printf("[Stage 3.5/5] Escalated for Senior Technical Review\n");
    } else if (strcmp(node->data.status, "RESOLVED") == 0) {
        printf("[Stage 4/5] Resolution Provided\n");
    } else if (strcmp(node->data.status, "CLOSED") == 0) {
        printf("[Stage 5/5] Formally Closed\n");
    } else {
        printf("Current State: %s\n", node->data.status);
    }
    printf("============================================================\n");
}

/* ========================================================================= */
/* FUNCTION 18: customerViewHistory                                          */
/* Displays chronological audit trail for a complaint filed by this customer */
/* ========================================================================= */
void customerViewHistory(const char *customerId) {
    char compId[16];
    readString("Enter Complaint ID for audit history: ", compId, sizeof(compId));

    ComplaintNode *node = findComplaintById(compId);
    if (node == NULL) {
        printf("Error: Complaint ID '%s' not found.\n", compId);
        return;
    }

    if (strcmp(node->data.customerId, customerId) != 0) {
        printf("Security violation: You can only view audit history for your own complaints.\n");
        return;
    }

    printf("\n=== Chronological Audit History: %s ===\n", node->data.complaintId);
    printf("%-19s | %-12s | %-12s | %s\n", "Timestamp", "Action", "Actor", "Details");
    printf("--------------------------------------------------------------------------------------\n");

    AuditNode *an = node->auditHead;
    int count = 0;
    while (an != NULL) {
        printf("%-19s | %-12s | %-12s | %s\n",
               an->timestamp, an->action, an->performedBy, an->details);
        an = an->next;
        count++;
    }

    if (count == 0) {
        printf("No audit records found for this complaint.\n");
    }
    printf("--------------------------------------------------------------------------------------\n");
}

/* ========================================================================= */
/* FUNCTION 19: agentMenu                                                    */
/* Submenu before login for predefined support agents                        */
/* ========================================================================= */
void agentMenu(void) {
    while (1) {
        printf("\n----------------------------------------\n");
        printf("             AGENT PORTAL\n");
        printf("----------------------------------------\n");
        printf("1. Login\n");
        printf("2. Return to main menu\n\n");

        int choice = readInt("Enter your choice: ", 1, 2);
        if (choice == 1) {
            char username[32], password[32];
            printf("\n=== Agent Login ===\n");
            readString("Agent Username: ", username, sizeof(username));
            readString("Agent Password: ", password, sizeof(password));

            int foundIdx = -1;
            for (int i = 0; i < MAX_AGENTS; i++) {
                if (strcmp(agents[i].username, username) == 0 &&
                    strcmp(agents[i].password, password) == 0) {
                    foundIdx = i;
                    break;
                }
            }

            if (foundIdx >= 0) {
                if (!agents[foundIdx].isActive) {
                    printf("\nAccess denied: Your agent account is currently set to Inactive. Contact Manager.\n");
                } else {
                    printf("\nWelcome, %s (%s)!\n", agents[foundIdx].fullName, agents[foundIdx].agentId);
                    agentDashboard(foundIdx);
                }
            } else {
                printf("\nAuthentication failed: Invalid agent username or password.\n");
            }
        } else {
            break;
        }
    }
}

/* ========================================================================= */
/* FUNCTION 20: agentDashboard                                               */
/* Agent dashboard displaying workload and operational options               */
/* ========================================================================= */
void agentDashboard(int agentIdx) {
    while (1) {
        int activeCount = 0;
        ComplaintNode *curr = complaintHead;
        while (curr != NULL) {
            if (strcmp(curr->data.assignedAgentId, agents[agentIdx].agentId) == 0) {
                if (strcmp(curr->data.status, "RESOLVED") != 0 &&
                    strcmp(curr->data.status, "CLOSED") != 0) {
                    activeCount++;
                }
            }
            curr = curr->next;
        }

        printf("\n----------------------------------------\n");
        printf("   AGENT DASHBOARD: %s (%s)\n", agents[agentIdx].fullName, agents[agentIdx].agentId);
        printf("   Active Workload: %d | Total Resolved: %d\n", activeCount, agents[agentIdx].resolvedCount);
        printf("----------------------------------------\n");
        printf("1. View assigned complaints\n");
        printf("2. Update complaint status & add note\n");
        printf("3. View complaint history\n");
        printf("4. Logout\n\n");

        int choice = readInt("Enter your choice: ", 1, 4);
        if (choice == 1) {
            agentViewAssigned(agents[agentIdx].agentId);
        } else if (choice == 2) {
            agentUpdateComplaint(agents[agentIdx].agentId);
        } else if (choice == 3) {
            char compId[16];
            readString("Enter Complaint ID for history: ", compId, sizeof(compId));
            ComplaintNode *node = findComplaintById(compId);
            if (node == NULL) {
                printf("Error: Complaint ID '%s' not found.\n", compId);
            } else {
                printf("\n=== Audit History for %s ===\n", node->data.complaintId);
                printf("%-19s | %-12s | %-12s | %s\n", "Timestamp", "Action", "Actor", "Details");
                printf("--------------------------------------------------------------------------------------\n");
                AuditNode *an = node->auditHead;
                while (an != NULL) {
                    printf("%-19s | %-12s | %-12s | %s\n", an->timestamp, an->action, an->performedBy, an->details);
                    an = an->next;
                }
                printf("--------------------------------------------------------------------------------------\n");
            }
        } else {
            printf("Logging out of agent portal...\n");
            break;
        }
    }
}

/* ========================================================================= */
/* FUNCTION 21: agentViewAssigned                                            */
/* Lists all complaints assigned to the logged-in agent                      */
/* ========================================================================= */
void agentViewAssigned(const char *agentId) {
    printf("\n=== Assigned Complaints for %s ===\n", agentId);
    printf("%-8s | %-10s | %-18s | %-8s | %-12s | %-19s\n",
           "ID", "Customer", "Category", "Priority", "Status", "Last Updated");
    printf("------------------------------------------------------------------------------------\n");

    int count = 0;
    ComplaintNode *curr = complaintHead;
    while (curr != NULL) {
        if (strcmp(curr->data.assignedAgentId, agentId) == 0) {
            printf("%-8s | %-10s | %-18s | %-8s | %-12s | %-19s\n",
                   curr->data.complaintId,
                   curr->data.customerId,
                   curr->data.category,
                   curr->data.priority,
                   curr->data.status,
                   curr->data.timestamps.updated);
            count++;
        }
        curr = curr->next;
    }

    if (count == 0) {
        printf("No complaints are currently assigned to you.\n");
    } else {
        printf("------------------------------------------------------------------------------------\n");
        printf("Total Assigned: %d\n", count);
    }
}

/* ========================================================================= */
/* FUNCTION 22: agentUpdateComplaint                                         */
/* Allows support agent to progress, resolve, or escalate an assigned ticket */
/* ========================================================================= */
void agentUpdateComplaint(const char *agentId) {
    char compId[16];
    readString("Enter Complaint ID to update: ", compId, sizeof(compId));

    ComplaintNode *node = findComplaintById(compId);
    if (node == NULL) {
        printf("Error: Complaint ID '%s' not found.\n", compId);
        return;
    }

    if (strcmp(node->data.assignedAgentId, agentId) != 0) {
        printf("Error: Complaint '%s' is not assigned to you (Assigned to: %s).\n",
               compId, node->data.assignedAgentId);
        return;
    }

    printf("\nUpdating Complaint: %s\n", node->data.complaintId);
    printf("Current Status: %s\n", node->data.status);
    printf("1. Mark IN_PROGRESS\n");
    printf("2. Mark RESOLVED\n");
    printf("3. Mark ESCALATED\n");
    printf("4. Cancel\n");

    int choice = readInt("Select action (1-4): ", 1, 4);
    if (choice == 4) {
        printf("Action cancelled.\n");
        return;
    }

    char note[128];
    readString("Enter progress/resolution/escalation note: ", note, sizeof(note));
    if (note[0] == '\0') {
        snprintf(note, sizeof(note), "Status updated by %s", agentId);
    }

    char now[26];
    getTimestamp(now, sizeof(now));
    snprintf(node->data.timestamps.updated, sizeof(node->data.timestamps.updated), "%s", now);
    snprintf(node->data.lastNote, sizeof(node->data.lastNote), "%s", note);

    if (choice == 1) {
        snprintf(node->data.status, sizeof(node->data.status), "IN_PROGRESS");
        addAuditEntry(node, "IN_PROGRESS", agentId, note);
        printf("[SUCCESS] Status updated to IN_PROGRESS.\n");
    } else if (choice == 2) {
        snprintf(node->data.status, sizeof(node->data.status), "RESOLVED");
        snprintf(node->data.timestamps.resolved, sizeof(node->data.timestamps.resolved), "%s", now);
        for (int i = 0; i < MAX_AGENTS; i++) {
            if (strcmp(agents[i].agentId, agentId) == 0) {
                agents[i].resolvedCount++;
                break;
            }
        }
        addAuditEntry(node, "RESOLVED", agentId, note);
        printf("[SUCCESS] Status updated to RESOLVED.\n");
    } else if (choice == 3) {
        snprintf(node->data.status, sizeof(node->data.status), "ESCALATED");
        snprintf(node->data.timestamps.escalated, sizeof(node->data.timestamps.escalated), "%s", now);
        addAuditEntry(node, "ESCALATED", agentId, note);
        printf("[SUCCESS] Complaint marked as ESCALATED for management review.\n");
    }

    saveAllData();
}

/* ========================================================================= */
/* FUNCTION 23: managerMenu                                                  */
/* Submenu before login for system administrator / operations manager        */
/* ========================================================================= */
void managerMenu(void) {
    while (1) {
        printf("\n----------------------------------------\n");
        printf("            MANAGER PORTAL\n");
        printf("----------------------------------------\n");
        printf("1. Login\n");
        printf("2. Return to main menu\n\n");

        int choice = readInt("Enter your choice: ", 1, 2);
        if (choice == 1) {
            char username[32], password[32];
            printf("\n=== Manager Login ===\n");
            readString("Manager Username: ", username, sizeof(username));
            readString("Manager Password: ", password, sizeof(password));

            if (strcmp(managerAccount.username, username) == 0 &&
                strcmp(managerAccount.password, password) == 0) {
                printf("\nWelcome, %s!\n", managerAccount.fullName);
                managerDashboard();
            } else {
                printf("\nAuthentication failed: Invalid manager credentials.\n");
            }
        } else {
            break;
        }
    }
}

/* ========================================================================= */
/* FUNCTION 24: managerDashboard                                             */
/* Manager dashboard with full administrative controls                       */
/* ========================================================================= */
void managerDashboard(void) {
    while (1) {
        printf("\n----------------------------------------\n");
        printf("           MANAGER DASHBOARD\n");
        printf("----------------------------------------\n");
        printf("1. View all complaints & system dashboard\n");
        printf("2. Assign / Reassign complaint to agent\n");
        printf("3. Update complaint status / close / escalate\n");
        printf("4. Agent management (workload & status)\n");
        printf("5. View complete system audit log\n");
        printf("6. Logout\n\n");

        int choice = readInt("Enter your choice: ", 1, 6);
        if (choice == 1) {
            managerViewAllComplaints();
        } else if (choice == 2) {
            managerAssignComplaint();
        } else if (choice == 3) {
            managerUpdateComplaint();
        } else if (choice == 4) {
            managerAgentManagement();
        } else if (choice == 5) {
            printf("\n=== Complete System Audit History ===\n");
            printf("%-8s | %-19s | %-12s | %-12s | %s\n",
                   "CMP ID", "Timestamp", "Action", "Actor", "Details");
            printf("--------------------------------------------------------------------------------------------\n");
            ComplaintNode *cNode = complaintHead;
            int count = 0;
            while (cNode != NULL) {
                AuditNode *aNode = cNode->auditHead;
                while (aNode != NULL) {
                    printf("%-8s | %-19s | %-12s | %-12s | %s\n",
                           aNode->complaintId, aNode->timestamp, aNode->action,
                           aNode->performedBy, aNode->details);
                    aNode = aNode->next;
                    count++;
                }
                cNode = cNode->next;
            }
            if (count == 0) {
                printf("No audit events logged in system yet.\n");
            }
            printf("--------------------------------------------------------------------------------------------\n");
        } else {
            printf("Logging out of manager session...\n");
            break;
        }
    }
}

/* ========================================================================= */
/* FUNCTION 25: managerViewAllComplaints                                     */
/* Displays metrics dashboard summary and complete complaints list           */
/* ========================================================================= */
void managerViewAllComplaints(void) {
    int total = 0, pending = 0, assigned = 0, inProg = 0, resolved = 0, closed = 0, escalated = 0;

    ComplaintNode *curr = complaintHead;
    while (curr != NULL) {
        total++;
        if (strcmp(curr->data.status, "PENDING") == 0) pending++;
        else if (strcmp(curr->data.status, "ASSIGNED") == 0) assigned++;
        else if (strcmp(curr->data.status, "IN_PROGRESS") == 0) inProg++;
        else if (strcmp(curr->data.status, "RESOLVED") == 0) resolved++;
        else if (strcmp(curr->data.status, "CLOSED") == 0) closed++;
        else if (strcmp(curr->data.status, "ESCALATED") == 0) escalated++;
        curr = curr->next;
    }

    printf("\n============================================================\n");
    printf("                SYSTEM METRICS & DASHBOARD\n");
    printf("============================================================\n");
    printf(" Total Complaints:  %-4d | Pending:     %-4d | Assigned:  %-4d\n", total, pending, assigned);
    printf(" In Progress:       %-4d | Escalated:   %-4d | Resolved:  %-4d\n", inProg, escalated, resolved);
    printf(" Closed:            %-4d\n", closed);
    printf("============================================================\n");

    printf("\n%-8s | %-10s | %-18s | %-8s | %-12s | %-8s | %-19s\n",
           "ID", "Customer", "Category", "Priority", "Status", "Agent", "Registered Date");
    printf("------------------------------------------------------------------------------------------------\n");

    curr = complaintHead;
    while (curr != NULL) {
        printf("%-8s | %-10s | %-18s | %-8s | %-12s | %-8s | %-19s\n",
               curr->data.complaintId,
               curr->data.customerId,
               curr->data.category,
               curr->data.priority,
               curr->data.status,
               curr->data.assignedAgentId,
               curr->data.timestamps.registered);
        curr = curr->next;
    }

    if (total == 0) {
        printf("Zero complaints exist in the system.\n");
    }
    printf("------------------------------------------------------------------------------------------------\n");
}

/* ========================================================================= */
/* FUNCTION 26: managerAssignComplaint                                       */
/* Manual assignment or reassignment of complaints to active agents          */
/* ========================================================================= */
void managerAssignComplaint(void) {
    char compId[16];
    readString("Enter Complaint ID to assign / reassign: ", compId, sizeof(compId));

    ComplaintNode *node = findComplaintById(compId);
    if (node == NULL) {
        printf("Error: Complaint ID '%s' not found.\n", compId);
        return;
    }

    printf("\nComplaint %s currently assigned to: %s (Status: %s)\n",
           node->data.complaintId, node->data.assignedAgentId, node->data.status);

    printf("\nAvailable Support Agents:\n");
    printf("%-8s | %-18s | %-8s | %-10s\n", "ID", "Name", "Status", "Workload");
    printf("----------------------------------------------------\n");
    for (int i = 0; i < MAX_AGENTS; i++) {
        int w = 0;
        ComplaintNode *c = complaintHead;
        while (c != NULL) {
            if (strcmp(c->data.assignedAgentId, agents[i].agentId) == 0 &&
                strcmp(c->data.status, "RESOLVED") != 0 &&
                strcmp(c->data.status, "CLOSED") != 0) {
                w++;
            }
            c = c->next;
        }
        printf("%-8s | %-18s | %-8s | %-10d\n",
               agents[i].agentId, agents[i].fullName,
               agents[i].isActive ? "ACTIVE" : "INACTIVE", w);
    }
    printf("----------------------------------------------------\n");

    char targetAgentId[16];
    readString("Enter Target Agent ID (e.g. AGT101): ", targetAgentId, sizeof(targetAgentId));

    int targetIdx = -1;
    for (int i = 0; i < MAX_AGENTS; i++) {
        if (strcmp(agents[i].agentId, targetAgentId) == 0) {
            targetIdx = i;
            break;
        }
    }

    if (targetIdx == -1) {
        printf("Error: Agent ID '%s' does not exist.\n", targetAgentId);
        return;
    }

    if (!agents[targetIdx].isActive) {
        printf("Warning: Agent %s is inactive. Reassignment aborted.\n", targetAgentId);
        return;
    }

    char now[26];
    getTimestamp(now, sizeof(now));
    snprintf(node->data.assignedAgentId, sizeof(node->data.assignedAgentId), "%s", targetAgentId);
    snprintf(node->data.timestamps.assigned, sizeof(node->data.timestamps.assigned), "%s", now);
    snprintf(node->data.timestamps.updated, sizeof(node->data.timestamps.updated), "%s", now);

    if (strcmp(node->data.status, "PENDING") == 0) {
        snprintf(node->data.status, sizeof(node->data.status), "ASSIGNED");
    }

    char auditMsg[128];
    snprintf(auditMsg, sizeof(auditMsg), "Reassigned by Manager to %s (%s)", agents[targetIdx].agentId, agents[targetIdx].fullName);
    snprintf(node->data.lastNote, sizeof(node->data.lastNote), "%s", auditMsg);
    addAuditEntry(node, "REASSIGNED", "MANAGER", auditMsg);

    saveAllData();
    printf("[SUCCESS] Complaint %s successfully assigned to %s.\n", compId, targetAgentId);
}

/* ========================================================================= */
/* FUNCTION 27: managerUpdateComplaint                                       */
/* Administrative status transition (In Progress, Resolved, Closed, Escalate)*/
/* ========================================================================= */
void managerUpdateComplaint(void) {
    char compId[16];
    readString("Enter Complaint ID to update: ", compId, sizeof(compId));

    ComplaintNode *node = findComplaintById(compId);
    if (node == NULL) {
        printf("Error: Complaint ID '%s' not found.\n", compId);
        return;
    }

    printf("\nManaging Complaint %s (Current Status: %s)\n", node->data.complaintId, node->data.status);
    printf("1. Mark IN_PROGRESS\n");
    printf("2. Mark RESOLVED\n");
    printf("3. Mark CLOSED\n");
    printf("4. Mark ESCALATED\n");
    printf("5. Cancel\n");

    int choice = readInt("Select administrative action (1-5): ", 1, 5);
    if (choice == 5) {
        printf("Action cancelled.\n");
        return;
    }

    char note[128];
    readString("Enter administrative note: ", note, sizeof(note));
    if (note[0] == '\0') {
        snprintf(note, sizeof(note), "Status updated by Manager");
    }

    char now[26];
    getTimestamp(now, sizeof(now));
    snprintf(node->data.timestamps.updated, sizeof(node->data.timestamps.updated), "%s", now);
    snprintf(node->data.lastNote, sizeof(node->data.lastNote), "%s", note);

    if (choice == 1) {
        snprintf(node->data.status, sizeof(node->data.status), "IN_PROGRESS");
        addAuditEntry(node, "IN_PROGRESS", "MANAGER", note);
        printf("[SUCCESS] Status updated to IN_PROGRESS.\n");
    } else if (choice == 2) {
        snprintf(node->data.status, sizeof(node->data.status), "RESOLVED");
        snprintf(node->data.timestamps.resolved, sizeof(node->data.timestamps.resolved), "%s", now);
        addAuditEntry(node, "RESOLVED", "MANAGER", note);
        printf("[SUCCESS] Status updated to RESOLVED.\n");
    } else if (choice == 3) {
        snprintf(node->data.status, sizeof(node->data.status), "CLOSED");
        snprintf(node->data.timestamps.closed, sizeof(node->data.timestamps.closed), "%s", now);
        addAuditEntry(node, "CLOSED", "MANAGER", note);
        printf("[SUCCESS] Status updated to CLOSED.\n");
    } else if (choice == 4) {
        snprintf(node->data.status, sizeof(node->data.status), "ESCALATED");
        snprintf(node->data.timestamps.escalated, sizeof(node->data.timestamps.escalated), "%s", now);
        addAuditEntry(node, "ESCALATED", "MANAGER", note);
        printf("[SUCCESS] Complaint ESCALATED.\n");
    }

    saveAllData();
}

/* ========================================================================= */
/* FUNCTION 28: managerAgentManagement                                       */
/* Views agent performance metrics and toggles active/inactive availability  */
/* Passwords are intentionally omitted for security as mandated              */
/* ========================================================================= */
void managerAgentManagement(void) {
    while (1) {
        printf("\n======================================================================\n");
        printf("                     SUPPORT AGENT MANAGEMENT\n");
        printf("======================================================================\n");
        printf("%-8s | %-18s | %-10s | %-8s | %-10s | %-10s\n",
               "Agent ID", "Full Name", "Username", "Status", "Workload", "Resolved");
        printf("----------------------------------------------------------------------\n");

        for (int i = 0; i < MAX_AGENTS; i++) {
            int w = 0;
            ComplaintNode *c = complaintHead;
            while (c != NULL) {
                if (strcmp(c->data.assignedAgentId, agents[i].agentId) == 0 &&
                    strcmp(c->data.status, "RESOLVED") != 0 &&
                    strcmp(c->data.status, "CLOSED") != 0) {
                    w++;
                }
                c = c->next;
            }
            printf("%-8s | %-18s | %-10s | %-8s | %-10d | %-10d\n",
                   agents[i].agentId, agents[i].fullName, agents[i].username,
                   agents[i].isActive ? "ACTIVE" : "INACTIVE", w, agents[i].resolvedCount);
        }
        printf("----------------------------------------------------------------------\n");
        printf("1. Toggle Agent Active / Inactive Status\n");
        printf("2. Return to Manager Menu\n\n");

        int choice = readInt("Enter your choice: ", 1, 2);
        if (choice == 1) {
            char agentId[16];
            readString("Enter Agent ID to toggle (e.g. AGT101): ", agentId, sizeof(agentId));
            int found = -1;
            for (int i = 0; i < MAX_AGENTS; i++) {
                if (strcmp(agents[i].agentId, agentId) == 0) {
                    found = i;
                    break;
                }
            }
            if (found != -1) {
                agents[found].isActive = !agents[found].isActive;
                saveAllData();
                printf("[SUCCESS] Agent %s status toggled to %s.\n",
                       agents[found].agentId, agents[found].isActive ? "ACTIVE" : "INACTIVE");
            } else {
                printf("Error: Agent ID '%s' not found.\n", agentId);
            }
        } else {
            break;
        }
    }
}

/* ========================================================================= */
/* FUNCTION 29: main                                                         */
/* Application entry point displaying mandatory 4-option main menu           */
/* ========================================================================= */
int main(void) {
    initSystem();

    while (1) {
        printf("\n========================================\n");
        printf("       COMPLAINT HANDLING SYSTEM\n");
        printf("========================================\n\n");
        printf("1. Customer\n");
        printf("2. Agent\n");
        printf("3. Manager\n");
        printf("4. Exit\n\n");

        int choice = readInt("Enter your choice: ", 1, 4);

        if (choice == 1) {
            customerMenu();
        } else if (choice == 2) {
            agentMenu();
        } else if (choice == 3) {
            managerMenu();
        } else if (choice == 4) {
            printf("\nSaving system state and releasing resources...\n");
            saveAllData();
            freeAllMemory();
            printf("Thank you for using the Complaint Handling System. Goodbye!\n");
            break;
        }
    }

    return 0;
}
